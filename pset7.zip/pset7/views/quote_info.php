<form action="quote.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="stock_name" placeholder="Stock To Quote" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Get Quote
            </button>
        </div>
        <h1><?php $stock["name"] ?></h1>
    <p>The price of <?=htmlspecialchars($stock["name"]) ?> is <?= htmlspecialchars($stock["price"]) ?></p>
    </fieldset>
</form>